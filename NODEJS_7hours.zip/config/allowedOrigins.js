const allowedOrigins = [
    "http://localhost:3500",
    "http://localhost:3001",
    "http://localhost:3000",
    "https://rhalupczok.github.io",
    "http://rhalupczok.github.io",
    "rhalupczok.github.io",
];

module.exports = allowedOrigins;
